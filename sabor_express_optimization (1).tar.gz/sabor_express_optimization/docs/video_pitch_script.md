# Roteiro do Vídeo Pitch (Máximo 4 Minutos)

## Título Sugerido: Sabor Express: Otimização Inteligente de Entregas com IA

### Duração Estimada: 3:45

---

### 1. Introdução e Problema (0:00 - 0:45)

| Tempo | Ação/Visual | Roteiro (Voz) |
| :--- | :--- | :--- |
| 0:00 | Tela de Título | Olá! Meu nome é [Seu Nome] e este é o projeto de otimização de rotas para a **Sabor Express**. |
| 0:10 | Imagem de Entregador Perdido/Trânsito | A Sabor Express, uma empresa de delivery, enfrenta um desafio comum: durante os horários de pico, a roteirização manual causa atrasos, aumenta o custo de combustível e gera insatisfação nos clientes. |
| 0:30 | Destaque: "Rotas Ineficientes" | O problema central é encontrar a rota mais rápida e econômica para múltiplos pedidos, um desafio clássico de logística que exige uma solução inteligente. |

### 2. Lógica da Solução Adotada (0:45 - 2:00)

| Tempo | Ação/Visual | Roteiro (Voz) |
| :--- | :--- | :--- |
| 0:45 | Diagrama da Solução Híbrida (K-Means + TSP) | Nossa solução é uma abordagem híbrida em duas fases, utilizando algoritmos de Inteligência Artificial. |
| 1:00 | Visualização do K-Means (Pontos Agrupados) | **Fase 1: Agrupamento Inteligente.** Utilizamos o algoritmo **K-Means** para agrupar os 20 pedidos em $K=4$ clusters, um para cada entregador. Isso garante que cada entregador atenda a uma zona geográfica coesa, minimizando o deslocamento entre as entregas. |
| 1:30 | Visualização do Grafo e A* | **Fase 2: Otimização da Rota.** Para cada cluster, o problema se torna um Caixeiro Viajante. Modelamos a cidade como um grafo e usamos o algoritmo **A\*** para calcular o custo real (distância) entre quaisquer dois pontos. |
| 1:45 | Destaque: Nearest Neighbor | Para encontrar a sequência ideal de visitas, aplicamos a heurística **Nearest Neighbor**, que garante que o entregador sempre vá para o ponto não visitado mais próximo, resultando em uma rota eficiente. |

### 3. Funcionamento do Código e Resultados (2:00 - 3:30)

| Tempo | Ação/Visual | Roteiro (Voz) |
| :--- | :--- | :--- |
| 2:00 | Tela do Código (route_optimizer.py) | O código, escrito em Python, implementa essa lógica. Ele carrega os dados simulados, aplica o K-Means e, em seguida, calcula a rota otimizada para cada um dos quatro entregadores. |
| 2:20 | Transição para o Gráfico de Resultados (`optimized_routes.png`) | O resultado é visualmente claro. Este gráfico mostra as quatro rotas otimizadas, partindo e retornando à Base (ponto preto). |
| 2:40 | Zoom no Gráfico, mostrando a Sequência | Observe que cada cor representa uma rota, e os números indicam a sequência de visitas determinada pelo nosso algoritmo. As rotas são compactas e cobrem áreas distintas. |
| 3:00 | Tabela de Resultados (Distância Total) | A métrica de sucesso é a distância total percorrida. Com a otimização, a distância total combinada das quatro rotas foi de **43.32 unidades euclidianas**. |
| 3:15 | Comparação com Cenário Manual (Estimativa) | Em um cenário manual, onde as rotas seriam aleatórias ou baseadas apenas na experiência, essa distância seria significativamente maior, resultando em mais tempo e custo. |

### 4. Conclusão e Próximos Passos (3:30 - 3:45)

| Tempo | Ação/Visual | Roteiro (Voz) |
| :--- | :--- | :--- |
| 3:30 | Tela de Agradecimento e Contato | Esta solução demonstra como a aplicação de fundamentos de IA, como clustering e busca heurística, pode transformar a eficiência operacional da Sabor Express. |
| 3:40 | Destaque: "Sugestões de Melhoria" | Como próximos passos, sugerimos integrar a solução com APIs de tráfego em tempo real e explorar algoritmos mais robustos de TSP, como o 2-opt, para refinar ainda mais as rotas. |
| 3:45 | Fim | Obrigado! |
