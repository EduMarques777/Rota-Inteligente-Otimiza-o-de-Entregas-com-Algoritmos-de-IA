# Arquitetura da Solução e Modelagem do Problema

## 1. Arquitetura da Solução: Abordagem Híbrida

A solução proposta para a "Sabor Express" adota uma arquitetura híbrida em duas fases, projetada para lidar com a complexidade do problema de roteamento de veículos (VRP) em horários de pico.

| Fase | Algoritmo de IA | Objetivo | Entrada | Saída |
| :--- | :--- | :--- | :--- | :--- |
| **1. Agrupamento** | K-Means (Aprendizado Não Supervisionado) | Dividir os pedidos em grupos geograficamente coesos, um para cada entregador/rota. | Lista de coordenadas (Lat, Lon) dos pedidos. | $K$ clusters de pedidos. |
| **2. Otimização de Rota** | A* (Busca Heurística) e Heurística TSP (Nearest Neighbor) | Encontrar a sequência ideal de visitas dentro de cada cluster, minimizando a distância total percorrida. | Grafo da cidade e pontos de um cluster. | Rota otimizada (sequência de pontos) para cada entregador. |

## 2. Modelagem do Problema

### 2.1. Representação da Cidade como um Grafo

A cidade é modelada como um grafo $G = (V, E)$, onde:

*   **V (Vértices/Nós):** Representam a base da "Sabor Express" e os locais de entrega (pedidos).
*   **E (Arestas):** Representam as ruas ou caminhos entre os locais.
*   **Peso da Aresta ($w_{ij}$):** O custo de percorrer a aresta entre o nó $i$ e o nó $j$. No nosso modelo simulado, o peso será a **distância euclidiana** entre os pontos, que serve como uma aproximação do tempo/distância real de viagem.

$$w_{ij} = \sqrt{(Lat_i - Lat_j)^2 + (Lon_i - Lon_j)^2}$$

### 2.2. Dados Simulados

Para a implementação, foram gerados dados simulados de 20 pedidos e a localização da base, conforme o arquivo `data/deliveries.csv`.

| ID | Tipo | Lat | Lon |
| :--- | :--- | :--- | :--- |
| 0 | Base | 0.0 | 0.0 |
| 1-20 | Delivery | Coordenadas simuladas | Coordenadas simuladas |

### 2.3. Algoritmos Detalhados

#### A. K-Means para Agrupamento

1.  **Entrada:** Coordenadas dos 20 pedidos.
2.  **Parâmetro $K$:** O número de clusters ($K$) será definido com base no número de entregadores disponíveis (ex: $K=4$ entregadores).
3.  **Métrica:** Distância Euclidiana.
4.  **Processo:** O K-Means particionará os 20 pontos em $K$ grupos, minimizando a soma dos quadrados das distâncias dos pontos aos centróides de seus respectivos clusters.

#### B. Otimização de Rota com A* e Heurística TSP

Para cada cluster gerado, o problema se torna um TSP de pequeno porte (Base + 5 a 6 entregas).

1.  **A* (A-Star):** Será usado para encontrar o caminho mais curto entre **quaisquer dois pontos** no grafo (ou seja, para calcular o peso real $w_{ij}$ entre os nós, simulando a busca em um mapa real).
    *   **Heurística $h(n)$:** Distância Euclidiana (linha reta) até o objetivo.
    *   **Função de Custo $g(n)$:** Distância percorrida até o nó $n$.

2.  **Heurística TSP (Nearest Neighbor):** Para determinar a sequência de visitas dentro do cluster.
    *   **Início:** Começa na Base.
    *   **Passo:** A cada passo, o entregador se move para o ponto de entrega **não visitado mais próximo** (menor $w_{ij}$).
    *   **Fim:** Retorna à Base após visitar todos os pontos do cluster.

Esta combinação garante que o desafio seja resolvido com algoritmos de IA clássicos (K-Means e A*) e uma heurística prática (Nearest Neighbor) para o problema de roteamento.
